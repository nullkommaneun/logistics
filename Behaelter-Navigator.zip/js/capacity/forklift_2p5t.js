
// Stub: capacity strategy for 2,5t forklift, max 2 containers of same class
export function splitTours(containers){
  // TODO v2
  return [containers];
}
