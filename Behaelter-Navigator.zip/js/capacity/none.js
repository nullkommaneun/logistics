
// v1 default capacity strategy: unlimited
export function splitTours(containers){ return [containers]; }
